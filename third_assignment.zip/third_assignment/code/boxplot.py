import pandas as pd
import datetime
import matplotlib.pyplot as plt
import numpy as np

format_str = '%d/%m/%Y'
dateparse = lambda x: datetime.datetime.strptime(x, format_str)
df = pd.read_csv("./../data/Mango_(Raw-Ripe)_2019.csv",parse_dates=['arrival_date'], date_parser=dateparse)
aa = df.groupby(['state'])['modal_price']#.plot(ax=ax,sharex=False)

bb = dict(list(aa))
state_names= aa.apply(lambda x: x.name)

fig, ax = plt.subplots(figsize=(15,7))
plt.boxplot([bb[i] for i in state_names],sym='+')#aa.groups.keys()])
plt.xticks(np.arange(1,len(bb)+1) , state_names,rotation = 20 )
plt.xlabel('state')
plt.ylabel('price per 100kg')
plt.title('distribution of mango prices in different states of india')
plt.grid(b=True, which='major', color='#666666', linestyle='-',alpha=0.25)
plt.minorticks_on()
plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
plt.tight_layout()
plt.savefig("../plot/boxplot.pdf")
plt.show() # a.apply(lambda x: x.name)