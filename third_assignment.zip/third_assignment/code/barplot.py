import pandas as pd
import datetime
import matplotlib.pyplot as plt

format_str = '%d/%m/%Y'
dateparse = lambda x: datetime.datetime.strptime(x, format_str)

df = pd.read_csv("./../data/Mango_(Raw-Ripe)_2019.csv",parse_dates=['arrival_date'], date_parser=dateparse)
aa = df.groupby(['state']).mean()['modal_price']#.plot(ax=ax,sharex=False)


# plotting
fig, ax = plt.subplots(figsize=(15,7))

plt.bar(aa.index,aa.values)
plt.xticks( rotation=40)
plt.xlabel('state')
plt.ylabel('price per 100kg')
plt.title('average price of mangoes per state of india')
plt.grid(b=True, which='major', color='#666666', linestyle='-',alpha=0.5)
plt.minorticks_on()
plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)

for i, v in enumerate(aa.values):
    plt.text(i -0.35, v + 1, str("{0:.2f}".format(round(v,2))))
    # print(i)
    # i+=1
plt.tight_layout()
plt.savefig("../plot/barplot.pdf")
plt.show()