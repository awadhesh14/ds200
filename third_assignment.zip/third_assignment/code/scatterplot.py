import pandas as pd
import datetime as dt
import matplotlib.pyplot as plt
import numpy as np
import calendar

format_str = '%d/%m/%Y'
dateparse = lambda x: dt.datetime.strptime(x, format_str)

df = pd.read_csv("./../data/Mango_(Raw-Ripe)_2019.csv",parse_dates=['arrival_date'], date_parser=dateparse)

df['month'] = df['arrival_date'].dt.month
df['day'] = df['arrival_date'].dt.day
df['month-str'] = df['arrival_date'].dt.strftime('%b')
months = list(set(df['month']))
monthsstr = [calendar.month_abbr[i] for i in months]
states = list(set(df['state']))
cmap = plt.get_cmap('viridis')
colors = cmap(np.linspace(0, 1, len(states)))

states = ['Punjab','Maharashtra','Himachal Pradesh','Gujarat','Madhya Pradesh','NCT of Delhi']#,'Haryana']#,'Kerela','Gujarat']
colors=['b','y','r','aqua','hotpink','black']#,'orange']#'r','b']
fig, ax = plt.subplots(figsize=(15,7))
df['x'] = df['month']+((df['day']-1)*0.033)
for i,(state,color) in enumerate(zip(states,colors),1):
    _df_ = df
    filter1 = _df_['state'] == state
    _df = _df_.where(filter1)
    _df = _df[_df.state.notnull()]
    _df['x'] = _df['month']+((_df['day']-1)*0.033)
    plt.scatter(_df['x'],_df['modal_price'],label=state,c=color,s=4)
    # print(_df)
    # print(df)
ax.set_xticks(range(1,len(monthsstr)+1))
ax.set_xticklabels(monthsstr)
plt.xlabel('month')
plt.ylabel('price per 100kg')
plt.title('average price of mangoes per month per state of india')
plt.grid(b=True, which='major', color='#666666', linestyle='-',alpha=0.23)
plt.minorticks_on()
plt.grid(b=True, which='minor', color='#999999', linestyle='-', alpha=0.2)
plt.legend()
plt.tight_layout()
plt.savefig("../plot/scatterplot.pdf")
plt.show()